GHANA QUICK LOANS — WEBSITE PACKAGE

Files:
- index.html: mobile-friendly static website with a working illustrative calculator and a preview-only enquiry form.

DEPLOYMENT
- GitHub: extract this ZIP and upload index.html (and README.txt) to the root of your ghana-quick-loans repository.
- Cloudflare Pages: choose Direct Upload and upload the extracted folder or ZIP.

IMPORTANT LIMITATIONS
This is a front-end website prototype. The calculator works in the browser. The enquiry form validates fields and displays a preview message, but it does NOT send or store submissions.
It is not a lending service, does not approve or disburse loans, and must not be represented as an authorised lender. Before accepting real customer information or offering loans, obtain appropriate Ghanaian legal/regulatory advice and authorisation, add a secure backend, privacy notice, data protection controls, identity checks where lawful, and verified lender/provider details.
No domain or hosting has been purchased or configured by this package.
